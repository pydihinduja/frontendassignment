import './App.css';
import searchimg from './search img.jpg';
import React, { useState } from 'react';
import data from './data.json';
function App() {
  
  const [rows, setRows] = useState(data.rows);
  const [isFormVisible, setFormVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({
    rowIndex: null,
    name: '',
    content: ''
  });

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const openForm = (rowIndex) => {
    setFormData({ ...formData, rowIndex });
    setFormVisible(true);
  };

  const closeForm = () => {
    setFormVisible(false);
    setFormData({ rowIndex: null, name: '', content: '' });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const addWidget = () => {
    const { rowIndex, name, content } = formData;

    if (name && content) {
      const newWidget = {
        id: Math.random(), // Unique ID for the new widget
        name: name,
        content: content,
      };

      const updatedRows = rows.map((row, index) => {
        if (index === rowIndex) {
          return { ...row, widgets: [...row.widgets, newWidget] };
        }
        return row;
      });

      setRows(updatedRows);
      closeForm(); // Close the form after adding the widget
    } else {
      alert("Please fill out both fields.");
    }
  };

  const removeWidget = (rowIndex, widgetIndex) => {
    const updatedRows = rows.map((row, index) => {
      if (index === rowIndex) {
        const updatedWidgets = row.widgets.filter((_, i) => i !== widgetIndex);
        return { ...row, widgets: updatedWidgets };
      }
      return row;
    });

    setRows(updatedRows);
  };


  return(
    <div className='main'>
      <div className='navbar'> 
          <span>Home {'>'} </span>
          <a href='self'>Dashboardv2</a>
          <img src={searchimg} alt=''></img>
          <input placeholder='search anything...' className='searchbar' 
          value={searchQuery}
          onChange={handleSearchChange}/>
          <button>Search</button>
      </div>

      <div className='dashboard'>
        <h4>CNAPP Dashboard</h4>  

        {rows.map((row, rowIndex) => {
          // Filter widgets based on the search query
          const filteredWidgets = row.widgets.filter(widget =>
            widget.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            widget.content.toLowerCase().includes(searchQuery.toLowerCase())
          );

          return (
            <div key={rowIndex} className='row-section'>
              <h5>{row.heading}</h5>
              <div className='row'>
                {filteredWidgets.length > 0 ? (
                  filteredWidgets.map((widget, widgetIndex) => (
                    <div key={widget.id} className='widget'>
                      <h6>{widget.name}</h6>
                      <p>{widget.content}</p>
                      <button onClick={() => removeWidget(rowIndex, widgetIndex)}>Remove</button>
                    </div>
                  ))
                ) : (
                  <p>No widgets found</p>
                )}
                <button className='add-widget' onClick={() => openForm(rowIndex)}>
                  + Add Widget
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sliding form */}
      <div className={`slide-form ${isFormVisible ? 'visible' : ''}`}>
        <div className='form-header'>
          <h3>Add New Widget</h3>
          <button onClick={closeForm}>Close</button>
        </div>
        <div className='form-body'>
          <input
            type='text'
            name='name'
            placeholder='Widget Name'
            value={formData.name}
            onChange={handleInputChange}
          />
          <textarea
            name='content'
            placeholder='Widget Content'
            value={formData.content}
            onChange={handleInputChange}
          />
          <button onClick={addWidget}>Add Widget</button>
        </div>
      </div>
    </div>
  );
}


export default App;
